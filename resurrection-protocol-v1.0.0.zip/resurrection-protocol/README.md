# Resurrection Protocol (RSP)

**Model-agnostic hardware discovery, debugging, bootstrap, and recovery toolkit.**

RSP gives an LLM or automation system a stable tool interface over hardware adapters. The model does not directly execute shell commands or manipulate device files. It calls bounded tools, while RSP applies policy, validates inputs, records operations, and reports structured evidence.

## Current implementation

This is a safe, extensible foundation, not a claim of universal hardware access.

Included:
- Model-agnostic MCP server over stdio (`rsp-mcp`), compatible with MCP-capable clients.
- CLI for discovery and diagnostics (`rsp`).
- Hardware discovery for host OS, serial ports, USB devices, and known debug/programming utilities.
- Read-only inventory tools.
- Explicitly gated execution of known tool adapters, with no shell interpolation.
- Durable JSONL audit events.
- Target profiles and capability-based operation checks.
- Schemas for target observations, operations, artifacts, and evidence.
- Optional hardware libraries are loaded only when installed.

Not included / not promised:
- Universal autodetection of unknown electrical interfaces.
- Automatic arbitrary flash writes.
- A target-side bootstrap that works on every board.
- Hardware-backed attestation on targets that lack it.

## Safety model

RSP defaults to **observe-only mode**. Discovery does not intentionally write to target hardware. Programming/debug operations are denied unless the operator explicitly enables write mode and configures the adapter. A policy gate still rejects unknown tools, shell commands, and unsafe arguments.

Use only on hardware you own or are authorized to test. Never probe unknown pins by applying arbitrary voltages. Confirm voltage levels, pinout, power/reset requirements, and adapter compatibility before connecting hardware.

## Requirements

- Python 3.11+
- Optional: an MCP-capable client for model tool access
- Optional host tools: `openocd`, `esptool`, `dfu-util`, `flashrom`, `avrdude`, `pyocd`
- Optional Python packages for richer inventory: `pyserial`, `pyusb`

## Install

From the project directory:

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1

pip install -e .
```

Install optional discovery dependencies:

```bash
pip install -e ".[hardware]"
```

## Use the CLI

```bash
rsp doctor
rsp discover
rsp adapters
rsp policy
```

`rsp discover` inventories the host and visible interfaces. It does not flash or reset devices.

## Connect an LLM

Run the MCP server:

```bash
rsp-mcp
```

Configure your MCP-capable LLM client to launch `rsp-mcp` as a local stdio server using the Python environment where RSP is installed. The exact client configuration varies by application.

The model receives tools such as:
- `rsp_status`
- `rsp_discover`
- `rsp_list_adapters`
- `rsp_get_target_profile`
- `rsp_validate_operation`
- `rsp_run_adapter_diagnostic`
- `rsp_read_audit_log`

The model does not receive a generic `run_shell` tool.

## First bring-up workflow

1. Run `rsp discover` with the target disconnected.
2. Connect only the intended, known-safe adapter.
3. Run `rsp discover` again and compare the observations.
4. Identify the board and exact revision from labels, documentation, and device identifiers.
5. Create a target profile from verified facts. Keep unknown values as `null` or `"unknown"`.
6. Run read-only diagnostics for the relevant adapter.
7. Enable write mode only after the hardware profile, voltage, wiring, and recovery path have been verified.
8. Before any write, verify the exact artifact hash, destination, target identity, and recovery plan.

## Write mode

RSP write mode is deliberately not enabled by default. To enable it for a controlled lab environment:

```bash
rsp --help
```

Set `RSP_ENABLE_WRITES=1` only after reviewing the policy and the selected adapter. This gate alone is not sufficient to make an operation safe. Hardware-specific operations should be added as explicit adapter methods with strict argument schemas, preconditions, timeout limits, and post-operation verification.

The initial release intentionally does **not** expose generic arbitrary flash-write or arbitrary debug-memory-write tools.

## Architecture

```text
LLM / automation
      |
      | MCP tool calls
      v
RSP MCP server ---- CLI / future HTTP gateway
      |
      v
Policy gate + operation state machine + audit log
      |
      +---- Host inventory adapter
      +---- Serial / USB discovery adapters
      +---- OpenOCD / esptool / DFU / flashrom diagnostics
      |
      v
Target hardware (only through supported, configured interfaces)
```

## Roadmap

- Add per-board profiles with signed, versioned manifests.
- Add a typed artifact store and reproducible build records.
- Add a target-side minimal monitor protocol.
- Add resumable artifact transfer and digest verification.
- Add transactional A/B image activation where hardware supports it.
- Add attestation integrations where hardware supports them.
- Add adapter conformance tests and simulated targets.
