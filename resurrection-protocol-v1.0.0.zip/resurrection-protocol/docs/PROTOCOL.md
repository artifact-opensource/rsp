# RSP Protocol Contract (v1.0)

## Design requirements

1. Model agnostic: models call stable tools; models are not coupled to adapter internals.
2. Capability driven: an operation exists only if an adapter explicitly declares it.
3. Fail closed: unknown operations, invalid arguments, missing preconditions, or invalid evidence do not authorize writes.
4. Observe first: inventory and diagnostics precede target mutation.
5. Evidence based: each transition records target, operation, artifact, result, and verifier.
6. Recoverable: destructive operations require a documented recovery path and durable job record.
7. Least privilege: no generic shell-execution capability is exposed.
8. Transport independent: logical operations are separate from UART, USB, debug, and network transports.
9. Explicit limitations: adapter availability is not proof that a target is compatible.

## Current built-in adapters

- `host.inventory`: host, serial, USB, and known tool inventory.
- `host.tool-probe`: allowlisted, bounded version diagnostics.

## Current model-facing operations

- `rsp_status`
- `rsp_discover`
- `rsp_list_adapters`
- `rsp_adapter_discover`
- `rsp_adapter_execute`
- `rsp_validate_operation`
- `rsp_run_adapter_diagnostic`
- `rsp_hash_artifact`
- `rsp_read_audit_log`

## Planned hardware operations

`target.identify`, `target.reset`, `artifact.transfer.begin`, `artifact.transfer.chunk`, `artifact.verify`, `artifact.execute`, `test.run`, `system.commit`, and `system.rollback` must be implemented per supported hardware profile. Listing a planned operation in documentation does not make it executable.

## Session states

`DISCONNECTED -> DISCOVERING -> PROFILED -> BOOTSTRAP_AVAILABLE -> BOOTSTRAPPED -> CONSTRUCTING -> VERIFYING -> COMMITTED`

Any stage may transition to `RECOVERY_REQUIRED` or `FAILED`. A profile is complete only when mandatory properties have adequate evidence. A target is not committed until configured acceptance tests pass.

## Operation contract

Every mutating operation must define target identity/profile, bounded arguments, preconditions, authorization, timeout/cancellation semantics, idempotency or safe retry behavior, expected state transition, postcondition checks, recovery plan, and audit record.

## Integrity and trust

CRC detects transmission errors, not identity. SHA-256 checks content integrity, not approval. Digital signatures require a trusted key policy. Hardware attestation is meaningful only when supported and correctly provisioned.
