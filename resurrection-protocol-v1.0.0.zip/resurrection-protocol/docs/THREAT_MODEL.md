# Threat Model

## Assets
- Target firmware and boot state
- Builder host and signing keys
- Artifact provenance
- Hardware availability and integrity
- Audit records and target identity

## Threats
- Wrong target selected
- Malformed or oversized protocol frames
- Malicious or compromised LLM proposing destructive operations
- Spoofed target identity or adapter output
- Corrupted or substituted artifacts
- Interrupted flash updates
- Untrusted build dependencies
- Prompt injection embedded in device strings or logs
- Accidental electrical damage during probing

## Controls in v1.0
- Observe-only default
- No generic shell tool
- Tool allowlist and bounded version checks
- Input length and file size limits
- Audit log
- Separate operation validation
- No implemented generic flash-write or debug-memory-write operation
- Documentation instructs treating device output as untrusted data

## Required before production writes
- Authenticated operator authorization
- Per-target policy and signed hardware profile
- Trusted signing key management
- Strict adapter argument schemas
- Safe cancellation and timeout behavior
- Recovery procedure tested on the actual hardware
- Atomic update or documented single-image recovery constraints
- Audit log integrity and retention policy
- Supply-chain controls for compilers and dependencies
- Independent post-write verification

## Non-goals
RSP cannot prove a device is safe merely because it is discoverable. It cannot infer unknown electrical specifications reliably from connector shape. It does not bypass access controls or secure boot.
