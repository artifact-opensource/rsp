"""Resurrection Protocol: model-agnostic hardware discovery and diagnostics."""

__version__ = "1.0.0"
