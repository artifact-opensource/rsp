"""Hardware adapter framework and built-in adapter registrations."""
