"""Typed adapter contracts for Resurrection Protocol.

Adapters must declare capabilities explicitly. An adapter's presence does not imply
that a target is identified or that destructive operations are safe.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from typing import Any, Literal
import time
import uuid


@dataclass(frozen=True)
class AdapterCapability:
    name: str
    description: str
    mutating: bool = False
    requires_target_profile: bool = True
    requires_authorization: bool = True
    risk: Literal["read-only", "low", "medium", "high", "critical"] = "read-only"


@dataclass
class AdapterResult:
    ok: bool
    adapter_id: str
    operation: str
    target_id: str | None
    started_at: float
    finished_at: float
    summary: str
    data: dict[str, Any] = field(default_factory=dict)
    evidence: list[dict[str, Any]] = field(default_factory=list)
    error: dict[str, Any] | None = None
    operation_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AdapterContext:
    """Runtime context passed to adapters; policy remains enforced by the registry."""
    write_enabled: bool = False
    target_profile: dict[str, Any] | None = None
    authorization_ref: str | None = None
    timeout_seconds: float = 10.0
    options: dict[str, Any] = field(default_factory=dict)


class HardwareAdapter(ABC):
    adapter_id: str = "abstract"
    display_name: str = "Abstract adapter"
    version: str = "1.0"
    description: str = ""
    capabilities: tuple[AdapterCapability, ...] = ()

    @abstractmethod
    def discover(self, context: AdapterContext) -> dict[str, Any]:
        """Discover adapter/target information without intentionally changing target state."""

    @abstractmethod
    def execute(self, operation: str, arguments: dict[str, Any], context: AdapterContext) -> AdapterResult:
        """Execute one registered operation. Implementations must validate arguments."""

    def manifest(self) -> dict[str, Any]:
        return {
            "adapter_id": self.adapter_id,
            "display_name": self.display_name,
            "version": self.version,
            "description": self.description,
            "capabilities": [asdict(cap) for cap in self.capabilities],
        }

    def capability(self, operation: str) -> AdapterCapability | None:
        return next((cap for cap in self.capabilities if cap.name == operation), None)


def result(adapter: HardwareAdapter, operation: str, target_id: str | None,
           started: float, summary: str, *, ok: bool = True,
           data: dict[str, Any] | None = None,
           evidence: list[dict[str, Any]] | None = None,
           error: dict[str, Any] | None = None) -> AdapterResult:
    return AdapterResult(
        ok=ok, adapter_id=adapter.adapter_id, operation=operation, target_id=target_id,
        started_at=started, finished_at=time.time(), summary=summary,
        data=data or {}, evidence=evidence or [], error=error,
    )
