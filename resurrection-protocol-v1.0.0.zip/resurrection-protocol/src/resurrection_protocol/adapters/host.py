"""Safe host inventory adapter."""
from __future__ import annotations
import platform
import shutil
import time
from typing import Any

from .base import AdapterCapability, AdapterContext, HardwareAdapter, result
from ..core import available_tools, discover_serial, discover_usb, host_status


class HostInventoryAdapter(HardwareAdapter):
    adapter_id = "host.inventory"
    display_name = "Host and interface inventory"
    version = "1.0"
    description = "Inventories host OS, serial/USB interfaces, and known debug tool availability."
    capabilities = (
        AdapterCapability("discover", "Inventory visible interfaces; no target writes.", False, False, False),
        AdapterCapability("tool_status", "Report allowlisted debug/programming tools.", False, False, False),
    )

    def discover(self, context: AdapterContext) -> dict[str, Any]:
        return {
            "adapter": self.manifest(),
            "host": host_status(),
            "serial": discover_serial(),
            "usb": discover_usb(),
            "tools": available_tools(),
        }

    def execute(self, operation: str, arguments: dict[str, Any], context: AdapterContext):
        started = time.time()
        if arguments:
            return result(self, operation, None, started, "Unexpected arguments.", ok=False,
                          error={"code": "unexpected_arguments", "allowed": []})
        if operation == "discover":
            return result(self, operation, None, started, "Host inventory completed.",
                          data=self.discover(context))
        if operation == "tool_status":
            return result(self, operation, None, started, "Tool inventory completed.",
                          data={"tools": available_tools()})
        return result(self, operation, None, started, "Operation is not supported.", ok=False,
                      error={"code": "unsupported_operation"})
