"""Adapter registry, capability introspection, and policy-enforced dispatch."""
from __future__ import annotations
import os
from typing import Any

from .base import AdapterContext, HardwareAdapter
from .host import HostInventoryAdapter
from .tool_probe import ToolProbeAdapter
from ..core import audit


class AdapterRegistry:
    def __init__(self, adapters: list[HardwareAdapter] | None = None):
        self._adapters: dict[str, HardwareAdapter] = {}
        for adapter in adapters if adapters is not None else [
            HostInventoryAdapter(), ToolProbeAdapter()
        ]:
            self.register(adapter)

    def register(self, adapter: HardwareAdapter) -> None:
        if not adapter.adapter_id or adapter.adapter_id in self._adapters:
            raise ValueError(f"Missing or duplicate adapter id: {adapter.adapter_id!r}")
        if not adapter.capabilities:
            raise ValueError(f"Adapter {adapter.adapter_id} must declare capabilities")
        self._adapters[adapter.adapter_id] = adapter
        audit("adapter.registered", {"adapter_id": adapter.adapter_id, "version": adapter.version})

    def list(self) -> list[dict[str, Any]]:
        return [self._adapters[key].manifest() for key in sorted(self._adapters)]

    def get(self, adapter_id: str) -> HardwareAdapter:
        try:
            return self._adapters[adapter_id]
        except KeyError as exc:
            raise ValueError(f"Unknown adapter: {adapter_id}") from exc

    def discover_all(self, context: AdapterContext | None = None) -> list[dict[str, Any]]:
        context = context or AdapterContext()
        output = []
        for adapter in self._adapters.values():
            try:
                output.append(adapter.discover(context))
            except Exception as exc:
                output.append({
                    "adapter": adapter.adapter_id,
                    "error": {"code": "adapter_discovery_error", "type": type(exc).__name__,
                              "message": str(exc)[:1000]}
                })
        return output

    def execute(self, adapter_id: str, operation: str, arguments: dict[str, Any] | None = None,
                context: AdapterContext | None = None) -> dict[str, Any]:
        arguments = arguments or {}
        context = context or AdapterContext(
            write_enabled=os.environ.get("RSP_ENABLE_WRITES") == "1"
        )
        adapter = self.get(adapter_id)
        capability = adapter.capability(operation)
        if capability is None:
            audit("operation.denied", {"adapter_id": adapter_id, "operation": operation,
                                       "reason": "capability_not_declared"})
            return {
                "ok": False, "adapter_id": adapter_id, "operation": operation,
                "error": {"code": "capability_not_declared"}
            }
        if capability.mutating and not context.write_enabled:
            audit("operation.denied", {"adapter_id": adapter_id, "operation": operation,
                                       "reason": "observe_only"})
            return {
                "ok": False, "adapter_id": adapter_id, "operation": operation,
                "error": {"code": "observe_only"}
            }
        if capability.requires_target_profile and not context.target_profile:
            return {
                "ok": False, "adapter_id": adapter_id, "operation": operation,
                "error": {"code": "target_profile_required"}
            }
        if capability.requires_authorization and not context.authorization_ref:
            return {
                "ok": False, "adapter_id": adapter_id, "operation": operation,
                "error": {"code": "authorization_required"}
            }
        try:
            response = adapter.execute(operation, arguments, context).to_dict()
        except Exception as exc:
            audit("operation.error", {"adapter_id": adapter_id, "operation": operation,
                                      "type": type(exc).__name__, "message": str(exc)[:1000]})
            return {
                "ok": False, "adapter_id": adapter_id, "operation": operation,
                "error": {"code": "adapter_exception", "type": type(exc).__name__,
                          "message": str(exc)[:1000]}
            }
        audit("operation.completed", {
            "adapter_id": adapter_id, "operation": operation,
            "ok": response.get("ok"), "operation_id": response.get("operation_id")
        })
        return response
