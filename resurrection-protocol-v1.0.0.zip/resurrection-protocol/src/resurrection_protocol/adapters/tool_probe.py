"""Allowlisted diagnostic adapter for installed host-side development tools.

Only fixed diagnostic arguments are used. No shell is invoked and user-supplied
arguments are never appended to commands.
"""
from __future__ import annotations
import time
from typing import Any

from .base import AdapterCapability, AdapterContext, HardwareAdapter, result
from ..core import KNOWN_TOOLS, run_tool_diagnostic


class ToolProbeAdapter(HardwareAdapter):
    adapter_id = "host.tool-probe"
    display_name = "Debug tool availability and diagnostics"
    version = "1.0"
    description = "Runs bounded, fixed-argument version checks for known toolchains and adapters."
    capabilities = (
        AdapterCapability("list_tools", "List allowlisted tools and availability.", False, False, False),
        AdapterCapability("diagnostic_version", "Run a fixed version diagnostic.", False, False, False),
    )

    def discover(self, context: AdapterContext) -> dict[str, Any]:
        from ..core import available_tools
        return {"adapter": self.manifest(), "tools": available_tools()}

    def execute(self, operation: str, arguments: dict[str, Any], context: AdapterContext):
        started = time.time()
        if operation == "list_tools":
            if arguments:
                return result(self, operation, None, started, "Unexpected arguments.", ok=False,
                              error={"code": "unexpected_arguments"})
            return result(self, operation, None, started, "Tool list returned.",
                          data=self.discover(context))
        if operation == "diagnostic_version":
            if set(arguments) != {"tool"} or not isinstance(arguments.get("tool"), str):
                return result(self, operation, None, started, "Expected only a tool name.", ok=False,
                              error={"code": "invalid_arguments", "required": ["tool"]})
            tool = arguments["tool"]
            if tool not in KNOWN_TOOLS:
                return result(self, operation, None, started, "Tool is not allowlisted.", ok=False,
                              error={"code": "tool_not_allowlisted"})
            payload = run_tool_diagnostic(tool)
            return result(self, operation, None, started, "Diagnostic completed.",
                          data=payload, evidence=[{"type": "tool_diagnostic", "tool": tool,
                                                   "status": payload.get("status")}])
        return result(self, operation, None, started, "Operation is not supported.", ok=False,
                      error={"code": "unsupported_operation"})
