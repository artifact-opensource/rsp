from __future__ import annotations

import argparse
import json
import os
import sys

from .adapters.registry import AdapterRegistry
from .core import (
    adapter_catalog, artifact_sha256, available_tools, discover, host_status,
    read_audit, run_tool_diagnostic, validate_operation,
)


def _print(value) -> None:
    print(json.dumps(value, indent=2, sort_keys=True, default=str))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rsp",
        description="Resurrection Protocol: model-agnostic hardware discovery and diagnostics",
    )
    parser.add_argument("--version", action="version", version="Resurrection Protocol 1.0.0")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor", help="show host status and tool availability")
    sub.add_parser("discover", help="inventory serial, USB, and known host tools")
    sub.add_parser("adapters", help="list registered adapters and capabilities")
    sub.add_parser("adapter-discover", help="run discovery on every registered adapter")
    execute = sub.add_parser("adapter-exec", help="execute a declared adapter operation")
    execute.add_argument("adapter_id")
    execute.add_argument("operation")
    execute.add_argument("--args-json", default="{}")
    execute.add_argument("--target-profile-json")
    execute.add_argument("--authorization-ref")
    execute.add_argument("--timeout", type=float, default=10.0)
    sub.add_parser("policy", help="show current write policy")
    diag = sub.add_parser("diagnostic", help="run an allowlisted tool version diagnostic")
    diag.add_argument("tool", help="allowlisted tool name")
    audit_cmd = sub.add_parser("audit", help="read recent audit records")
    audit_cmd.add_argument("--limit", type=int, default=50)
    hash_cmd = sub.add_parser("hash", help="calculate SHA-256 of a local artifact")
    hash_cmd.add_argument("path")
    validate = sub.add_parser("validate", help="validate whether a named operation is currently allowed")
    validate.add_argument("operation")
    validate.add_argument("--args-json", default="{}")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    try:
        if args.command == "doctor":
            _print({"status": host_status(), "tools": available_tools()})
        elif args.command == "discover":
            _print(discover())
        elif args.command == "adapters":
            _print(AdapterRegistry().list())
        elif args.command == "adapter-discover":
            _print({"schema": "rsp.adapter-discovery.v1",
                    "adapters": AdapterRegistry().discover_all()})
        elif args.command == "adapter-exec":
            from .adapters.base import AdapterContext
            raw_args = json.loads(args.args_json)
            if not isinstance(raw_args, dict):
                raise ValueError("--args-json must decode to an object")
            profile = json.loads(args.target_profile_json) if args.target_profile_json else None
            if profile is not None and not isinstance(profile, dict):
                raise ValueError("--target-profile-json must decode to an object")
            context = AdapterContext(
                write_enabled=os.environ.get("RSP_ENABLE_WRITES") == "1",
                target_profile=profile,
                authorization_ref=args.authorization_ref,
                timeout_seconds=max(0.1, min(args.timeout, 3600.0)),
            )
            _print(AdapterRegistry().execute(args.adapter_id, args.operation, raw_args, context))
        elif args.command == "policy":
            _print({
                "mode": "write-enabled" if os.environ.get("RSP_ENABLE_WRITES") == "1" else "observe-only",
                "generic_shell": False,
                "arbitrary_flash_write": False,
                "arbitrary_debug_memory_write": False,
                "note": "Write enablement does not create a write adapter; mutating operations must be explicitly implemented."
            })
        elif args.command == "diagnostic":
            _print(run_tool_diagnostic(args.tool))
        elif args.command == "audit":
            _print(read_audit(args.limit))
        elif args.command == "hash":
            _print(artifact_sha256(args.path))
        elif args.command == "validate":
            _print(validate_operation(args.operation, json.loads(args.args_json)))
        else:
            raise ValueError("Unknown command")
    except (ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        raise SystemExit(2)
