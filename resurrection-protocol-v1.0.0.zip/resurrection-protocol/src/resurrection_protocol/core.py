from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

APP_NAME = "resurrection-protocol"
KNOWN_TOOLS = {
    "openocd": ["--version"],
    "esptool": ["version"],
    "esptool.py": ["version"],
    "dfu-util": ["--version"],
    "flashrom": ["--version"],
    "avrdude": ["-?"],
    "pyocd": ["--version"],
    "arm-none-eabi-gcc": ["--version"],
    "aarch64-linux-gnu-gcc": ["--version"],
    "clang": ["--version"],
    "llvm-objdump": ["--version"],
    "gdb-multiarch": ["--version"],
}
MAX_DIAGNOSTIC_SECONDS = 8
MAX_OUTPUT_CHARS = 6000


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def data_dir() -> Path:
    if os.environ.get("RSP_DATA_DIR"):
        path = Path(os.environ["RSP_DATA_DIR"]).expanduser()
    elif os.name == "nt":
        path = Path(os.environ.get("LOCALAPPDATA", Path.home())) / APP_NAME
    else:
        path = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local/state")) / APP_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def audit_path() -> Path:
    return data_dir() / "audit.jsonl"


def audit(event: str, details: dict[str, Any]) -> dict[str, Any]:
    record = {
        "timestamp": utc_now(),
        "event_id": str(uuid.uuid4()),
        "event": event,
        "details": details,
    }
    with audit_path().open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True, default=str) + "\n")
    return record


def read_audit(limit: int = 100) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 1000))
    path = audit_path()
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    result = []
    for line in lines[-limit:]:
        try:
            result.append(json.loads(line))
        except json.JSONDecodeError:
            result.append({"parse_error": True, "raw": line[:1000]})
    return result


def host_status() -> dict[str, Any]:
    return {
        "product": "Resurrection Protocol",
        "version": "1.0.0",
        "mode": "write-enabled" if os.environ.get("RSP_ENABLE_WRITES") == "1" else "observe-only",
        "host": {
            "os": platform.system(),
            "os_release": platform.release(),
            "architecture": platform.machine(),
            "python": platform.python_version(),
        },
        "data_dir": str(data_dir()),
        "audit_log": str(audit_path()),
    }


def available_tools() -> list[dict[str, Any]]:
    found = []
    for name, version_args in KNOWN_TOOLS.items():
        path = shutil.which(name)
        found.append({
            "name": name,
            "available": bool(path),
            "path": path,
            "diagnostic_args": version_args,
            "category": "compiler" if ("gcc" in name or name in {"clang", "llvm-objdump", "gdb-multiarch"}) else "hardware-tool",
        })
    return found


def discover_serial() -> dict[str, Any]:
    try:
        from serial.tools import list_ports
    except ImportError:
        return {"available": False, "reason": "pyserial is not installed", "ports": []}
    ports = []
    for port in list_ports.comports():
        ports.append({
            "device": port.device,
            "description": port.description,
            "manufacturer": port.manufacturer,
            "product": port.product,
            "vid": f"0x{port.vid:04x}" if port.vid is not None else None,
            "pid": f"0x{port.pid:04x}" if port.pid is not None else None,
            "serial_number_present": bool(port.serial_number),
            "hwid": port.hwid,
        })
    return {"available": True, "ports": ports}


def discover_usb() -> dict[str, Any]:
    try:
        import usb.core
        import usb.util
    except ImportError:
        return {"available": False, "reason": "pyusb is not installed", "devices": []}
    devices = []
    try:
        for dev in usb.core.find(find_all=True):
            devices.append({
                "vid": f"0x{dev.idVendor:04x}",
                "pid": f"0x{dev.idProduct:04x}",
                "bus": dev.bus,
                "address": dev.address,
                "manufacturer": _usb_string(dev, dev.iManufacturer),
                "product": _usb_string(dev, dev.iProduct),
                "serial_number_present": bool(dev.iSerialNumber),
            })
    except Exception as exc:
        return {"available": True, "devices": devices, "warning": f"USB enumeration issue: {type(exc).__name__}: {exc}"}
    return {"available": True, "devices": devices}


def _usb_string(dev: Any, index: int) -> str | None:
    if not index:
        return None
    try:
        import usb.util
        return usb.util.get_string(dev, index)
    except Exception:
        return None


def discover() -> dict[str, Any]:
    result = {
        "schema": "rsp.discovery.v1",
        "timestamp": utc_now(),
        "host": host_status()["host"],
        "serial": discover_serial(),
        "usb": discover_usb(),
        "tools": available_tools(),
        "note": "Inventory only. No target reset, probe waveform, or write operation is initiated.",
    }
    audit("discovery.completed", {
        "serial_ports": len(result["serial"].get("ports", [])),
        "usb_devices": len(result["usb"].get("devices", [])),
        "tools_available": sum(1 for t in result["tools"] if t["available"]),
    })
    return result


def adapter_catalog() -> list[dict[str, Any]]:
    return [
        {
            "id": "host-inventory",
            "status": "available",
            "operations": ["host_status", "discover"],
            "writes_target": False,
            "description": "Host OS, serial, USB, and installed-tool inventory.",
        },
        {
            "id": "openocd",
            "status": "available" if shutil.which("openocd") else "missing-tool",
            "operations": ["diagnostic_version"],
            "writes_target": False,
            "description": "OpenOCD availability/version check only in this release.",
        },
        {
            "id": "esptool",
            "status": "available" if shutil.which("esptool") or shutil.which("esptool.py") else "missing-tool",
            "operations": ["diagnostic_version"],
            "writes_target": False,
            "description": "Espressif tool availability/version check only in this release.",
        },
        {
            "id": "dfu-util",
            "status": "available" if shutil.which("dfu-util") else "missing-tool",
            "operations": ["diagnostic_version"],
            "writes_target": False,
            "description": "USB DFU tool availability/version check only in this release.",
        },
        {
            "id": "flashrom",
            "status": "available" if shutil.which("flashrom") else "missing-tool",
            "operations": ["diagnostic_version"],
            "writes_target": False,
            "description": "Flashrom availability/version check only in this release.",
        },
    ]


def run_tool_diagnostic(name: str) -> dict[str, Any]:
    if name not in KNOWN_TOOLS:
        raise ValueError(f"Tool is not allowlisted: {name}")
    executable = shutil.which(name)
    if not executable:
        result = {"tool": name, "available": False, "status": "missing"}
        audit("tool_diagnostic.missing", {"tool": name})
        return result
    args = KNOWN_TOOLS[name]
    try:
        completed = subprocess.run(
            [executable, *args],
            capture_output=True,
            text=True,
            timeout=MAX_DIAGNOSTIC_SECONDS,
            check=False,
            shell=False,
            env={"PATH": os.environ.get("PATH", ""), "SYSTEMROOT": os.environ.get("SYSTEMROOT", "")},
        )
        result = {
            "tool": name,
            "available": True,
            "path": executable,
            "args": args,
            "return_code": completed.returncode,
            "stdout": completed.stdout[-MAX_OUTPUT_CHARS:],
            "stderr": completed.stderr[-MAX_OUTPUT_CHARS:],
            "status": "diagnostic-completed",
        }
    except subprocess.TimeoutExpired:
        result = {"tool": name, "available": True, "path": executable, "status": "timeout"}
    except OSError as exc:
        result = {"tool": name, "available": True, "path": executable, "status": "execution-error", "error": str(exc)}
    audit("tool_diagnostic.completed", {
        "tool": name,
        "status": result.get("status"),
        "return_code": result.get("return_code"),
    })
    return result


def validate_operation(operation: str, args: dict[str, Any] | None = None) -> dict[str, Any]:
    args = args or {}
    known = {
        "discover": {"writes_target": False, "required": []},
        "host_status": {"writes_target": False, "required": []},
        "list_adapters": {"writes_target": False, "required": []},
        "diagnostic_version": {"writes_target": False, "required": ["tool"]},
        "read_audit": {"writes_target": False, "required": []},
        "flash_write": {"writes_target": True, "required": ["target_profile", "artifact_sha256", "recovery_plan"]},
        "debug_memory_write": {"writes_target": True, "required": ["target_profile", "address", "length", "authorization"]},
    }
    if operation not in known:
        return {"allowed": False, "operation": operation, "reason": "operation-not-registered"}
    spec = known[operation]
    missing = [key for key in spec["required"] if key not in args or args[key] in (None, "")]
    if missing:
        return {"allowed": False, "operation": operation, "reason": "missing-required-fields", "missing": missing}
    if spec["writes_target"] and os.environ.get("RSP_ENABLE_WRITES") != "1":
        return {"allowed": False, "operation": operation, "reason": "observe-only-mode"}
    # This initial release deliberately has no implementation for write operations.
    if operation in {"flash_write", "debug_memory_write"}:
        return {"allowed": False, "operation": operation, "reason": "write-adapter-not-implemented"}
    return {"allowed": True, "operation": operation, "writes_target": False, "reason": "registered-read-only-operation"}


def artifact_sha256(path: str) -> dict[str, Any]:
    file_path = Path(path).expanduser().resolve()
    if not file_path.is_file():
        raise ValueError("Artifact path must refer to an existing regular file")
    size = file_path.stat().st_size
    if size > 2 * 1024 * 1024 * 1024:
        raise ValueError("Artifact exceeds 2 GiB inspection limit")
    digest = hashlib.sha256()
    with file_path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    result = {"path": str(file_path), "size_bytes": size, "sha256": digest.hexdigest(), "algorithm": "sha256"}
    audit("artifact.hashed", {"path": str(file_path), "size_bytes": size, "sha256": result["sha256"]})
    return result
