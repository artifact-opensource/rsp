import unittest
from resurrection_protocol.adapters.base import AdapterContext
from resurrection_protocol.adapters.registry import AdapterRegistry


class AdapterFrameworkTests(unittest.TestCase):
    def setUp(self):
        self.registry = AdapterRegistry()

    def test_builtin_adapters_registered(self):
        ids = {item["adapter_id"] for item in self.registry.list()}
        self.assertIn("host.inventory", ids)
        self.assertIn("host.tool-probe", ids)

    def test_unknown_capability_denied(self):
        result = self.registry.execute("host.inventory", "flash_write", {})
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"]["code"], "capability_not_declared")

    def test_inventory_discovery_is_available(self):
        result = self.registry.execute("host.inventory", "discover", {})
        self.assertTrue(result["ok"])
        self.assertIn("host", result["data"])

    def test_diagnostic_rejects_extra_arguments(self):
        result = self.registry.execute("host.tool-probe", "diagnostic_version", {"tool": "clang", "args": ["x"]})
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"]["code"], "invalid_arguments")

    def test_registry_rejects_duplicate_ids(self):
        from resurrection_protocol.adapters.host import HostInventoryAdapter
        with self.assertRaises(ValueError):
            self.registry.register(HostInventoryAdapter())


if __name__ == "__main__":
    unittest.main()
