import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from resurrection_protocol.core import validate_operation, artifact_sha256, adapter_catalog


class CoreTests(unittest.TestCase):
    def test_unknown_operation_denied(self):
        result = validate_operation("do_anything", {})
        self.assertFalse(result["allowed"])
        self.assertEqual(result["reason"], "operation-not-registered")

    def test_write_denied_by_default(self):
        with patch.dict(os.environ, {}, clear=True):
            result = validate_operation("flash_write", {
                "target_profile": "board-a",
                "artifact_sha256": "a" * 64,
                "recovery_plan": "external-rom"
            })
        self.assertFalse(result["allowed"])
        self.assertEqual(result["reason"], "observe-only-mode")

    def test_write_adapter_not_implemented_even_if_enabled(self):
        with patch.dict(os.environ, {"RSP_ENABLE_WRITES": "1"}):
            result = validate_operation("flash_write", {
                "target_profile": "board-a",
                "artifact_sha256": "a" * 64,
                "recovery_plan": "external-rom"
            })
        self.assertFalse(result["allowed"])
        self.assertEqual(result["reason"], "write-adapter-not-implemented")

    def test_hash_artifact(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "artifact.bin"
            path.write_bytes(b"abc")
            result = artifact_sha256(str(path))
            self.assertEqual(result["size_bytes"], 3)
            self.assertEqual(result["sha256"], "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")

    def test_adapters_have_read_only_initial_scope(self):
        adapters = adapter_catalog()
        self.assertTrue(all(item["writes_target"] is False for item in adapters))


if __name__ == "__main__":
    unittest.main()
